package com.example.lemodateapp



val screenData = listOf(
    ScreenContent(1,R.drawable.lemon_tree,R.string.Lemon_tree),
    ScreenContent(2,R.drawable.lemon_squeeze,R.string.lemon),
    ScreenContent(3,R.drawable.lemon_drink,R.string.glass_of_lemonade),
    ScreenContent(4,R.drawable.lemon_restart,R.string.empty_glass)
)

fun goNext(){

}